# GATE 0 — Audit inventory (final-evidence pass)

Date: 2026-10-17. Branch: devin/1792275721-pcum-cor-gate (PR #702).
Canonical tree: package_consumption_unit_mismatch/. Current commit:
646bb41e1 (+ this pass's changes).

## Canonical files

- Manuscript source: manuscript/manuscript_source.md → generated docx
  (blinded_submission / blinded_review / supplement / title_page /
  cover_letter / highlights.txt)
- Values registry: manuscript_values.csv (27 rows)
- Canonical results: output/*.csv (26 files + 2 .csv.gz replication logs)
- Generators: analysis/{run_analysis,run_revision_analyses,build_tables,
  build_figures,build_manuscript,build_submission}.py; src/pcum/model.py;
  config/default.yaml
- Submission package: submission/COR/ + COR_transfer_FINAL_VERIFIED.zip
  (renamed each audit pass; CAIE/IJPE dirs preserved at HEAD, untouched)

## Existing audits found (verified present, substantive, current)

| Report | Date | Scope | Findings | Status |
|---|---|---|---|---|
| COR_GATE0_FEASIBILITY.md | 2026-10-17 | COR scope/fees/transfer | PASS | recovered |
| COR_NOVELTY_VERDICT.md + COR_CLOSEST_PRIOR_STUDIES.csv | 2026-10-17 | 11-paper prior-art, novelty | conditional→PASS via greedy falsification | recovered |
| COR_GATE2_SCIENTIFIC_VERDICT.md | 2026-10-17 | soundness | PASS | recovered |
| COR_HOSTILE_REVIEW.md | 2026-10-17 | 6-persona hostile review | no fatal; FIX items logged | recovered |
| COR_NUMERIC_HARDCODE_AUDIT.md + COR_NUMERIC_CLAIMS_TRACE.csv | 2026-10-17 | provenance audit | no prohibited hardcoding | recovered |
| COR_FINAL_DECISION.md | 2026-10-17 | gate decision | GO | recovered |
| COR_BASELINE_MEMO.md | 2026-10-17 | baseline | — | recovered |
| COR_FINAL_HOSTILE_REVIEW.md | 2026-10-17 | 10-question final hostile review | no CRITICAL; residual MAJOR (interpretive novelty) | recovered — **required report 1** |
| COR_FINAL_HARDCODE_AUDIT.md + COR_NUMERIC_PROVENANCE.csv | 2026-10-17 | code-level literal/stale scan of all generators | zero result literals; PASS | recovered — **required report 2** |
| COR_FINAL_NUMERIC_AUDIT.md | 2026-10-17 | per-value verification vs canonical CSVs | all 20 values verified | recovered — **required report 3** |
| COR_TEXT_FIGURE_TABLE_CONSISTENCY.md | 2026-10-17 | regenerated figures/tables + rendered docx | PASS | recovered |
| COR_FINAL_CLAIM_AND_CITATION_AUDIT.md | 2026-10-17 | DOIs, entailment, cover-letter phrasing | PASS after fixes | recovered |
| COR_FINAL_AUDIT_DECISION.md | 2026-10-17 | final gate decision | GO (technical readiness) | recovered — **required report 4** |
| COR_FILE_ROLE_MAP.md | 2026-10-17 | zip contents map | current | recovered |

## Supporting machine audits (run_audits.py suites)

13+ CSV suites in reports/*_audit.csv — all PASS on current build:
reference, numeric traceability, hardcode, figure/table, figure quality,
submission compliance, fabrication risk, archive anonymity, citation
entailment, etc.

## Gaps found and closed this pass

- Cover letter: "marks the exact boundary" overclaim → replaced with
  sufficient-condition phrasing (Gate 5, this prompt).
- Cover letter: "publicly archived" → accurate "available in a public
  GitHub repository" (repo verified public, no DOI exists).
- Zip/evidence split: journal ZIP = submission files only; audit
  reports now shipped as COR_FINAL_AUDIT_EVIDENCE.zip + loose md/csv.

No missing audits — all four required reports existed with substantive
content; verified by direct reading, not inherited PASS.
