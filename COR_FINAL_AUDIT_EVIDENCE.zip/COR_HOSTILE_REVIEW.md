# GATE 1 — Hostile scientific & editorial review (COR revision)

Date: 2026-10-17. Baseline: reports/COR_BASELINE_MEMO.md.
Six reviewer personas: (1) COR handling editor, (2) combinatorial
optimization specialist, (3) stochastic inventory researcher,
(4) assortment/product-variety scholar, (5) simulation/statistics
reviewer, (6) empirical operations researcher.
Ranked by effect on COR editorial viability. Status codes:
RES = resolved by existing text, FIX = targeted revision implemented
in Gate 4, ACC = accepted limitation disclosed honestly.

---

## Fatal-tier candidates

### A1 — "Nothing is new: conservation identity + algebra + textbook greedy"
[Editor + optimization specialist] SEVERITY: major (not fatal).
The lemma is indeed a conservation identity — the manuscript itself says
so ("consistency check", §2.2, proof at line 55), and its function is to
bound when the remainder-equals-waste shortcut is valid, not to be a
theorem for its own sake. The break-even condition is an algebraic
rearrangement — again stated as such ("a global SKU-inclusion condition
whose necessity is demonstrated, not assumed"). The defensible residue:
(a) each consumer SKU's value is generated endogenously by a stochastic
household inventory process rather than assumed as an exogenous
choice/substitution function (contrast: Gaur & Honhon 2006; Kök & Fisher
2007; van Ryzin & Mahajan 1999); (b) the inclusion decision is shown —
computationally, not anecdotally — to require globally evaluated optima,
because greedy fails on the realistic feasible set (6/10 regimes). This
is integrative, not algorithmic, novelty; the manuscript already says
exactly this (§4.1, line 242). STATUS: RES, with two tightening edits
(FIX-1: abstract/discussion wording already calibrated in COR pass;
verify no residual "new algorithm" implication — confirmed none).

### A2 — "Non-nestedness is a known property of non-submodular assortment"
[Assortment scholar] SEVERITY: major.
True as an abstract possibility; the paper's contribution is narrower
and defensible: in *this* feasible set (realistic package sizes,
complexity charge, endogenous SKU values), non-nestedness binds at the
first inclusion step and greedy loses a quantified amount. The claim is
computational, not a general theorem — and the manuscript says
"in 6 of 10 prespecified regimes", never "always" or "in general".
STATUS: RES. FIX-2 (minor): state explicitly that the failure is
confined to the first inclusion decision (greedy regret at k=3 is 0 in
all 10 regimes), which prevents a referee from discovering and
weaponizing that fact.

### B — Closest prior studies
[All] SEVERITY: major. reports/COR_CLOSEST_PRIOR_STUDIES.csv lists 11
verified papers; the strongest pressure comes from
Gaur & Honhon (2006) and Kök & Fisher (2007) — assortment-plus-inventory
with substitution demand. Difference: their SKU value function is
exogenous (locational choice / substitution matrix); here it is
endogenous to a per-household FIFO inventory process with
usage-quantum lattices. No package-size or lot-sizing paper in the set
carries household inventory state into a portfolio decision; no
assortment paper carries a package-capacity lattice. STATUS: RES; the
Discussion paragraph (line 242) already makes this exact contrast.

---

## Major-tier

### C — Greedy gap verification
[Optimization specialist + simulation reviewer] SEVERITY: major → verified.
Definition (analysis/run_revision_analyses.py:760): retain the globally
best (k−1)-SKU set, add the argmin next SKU; feasible set = all
singles/pairs/triples over the 10 candidate sizes; comparator = global
argmin over the same cardinality; deterministic argmin, no ties present
in any regime (checked — each argmin unique); uncertainty: the
comparison uses regime system-cost means; replication-level CIs exist for
portfolio contrasts but greedy regret inherits the same MC noise — the
gap (106–113 JPY) is ~60× the contrast SE (~1.7 JPY), so MC noise
cannot explain it. STATUS: RES. Manuscript already reports "at the
second SKU" — accurate; FIX-2 adds the k=3 observation.

### D — Do negative controls undercut the premise?
[Simulation reviewer] SEVERITY: minor.
The lattice adds zero discard and is second-order in cost — which the
paper reports honestly (§3.2, §4.2) as a *finding*, not a premise. A
referee could still say "so granularity does not matter"; the answer is
in the text: mismatch operates through adaptation, aging, and storage,
not through residue-waste (line 246). The framing does not overstate —
if anything it deflates a common intuition. STATUS: RES.

### E — Objective mixes transfers with resource costs
[Empirical OR researcher] SEVERITY: major.
product_cost = throughput × effective price (850 JPY/kg × size
discount) — purchase outlay, partly a transfer. The objective is a
household-side generalized cost, which legitimately includes outlay;
and the *differences* between portfolios arise from spoilage-driven
repurchasing, purchase frequency, and discount terms, not the transfer
level (total consumption is demand-fixed). The current text lists the
components (§2.3 line 63) but does not say this explicitly.
STATUS: FIX-3 — add one clarifying sentence in §2.4 (objective
definition) noting outlay is a real household cost and that
cross-portfolio differences reflect spoilage/behavior, not the transfer
level.

### F — Parameter identification / MC vs parameter uncertainty
[Statistics reviewer] SEVERITY: minor → RES.
§3.2 line 109 and §4.3 line 260 already state MC intervals quantify
simulation error only, list 8 unidentified + 6 scenario-assumption
inputs, and label thresholds as scenario quantities. STATUS: RES.

---

## Minor-tier

### G — Model validity mechanics
[Stochastic inventory researcher] SEVERITY: minor → RES.
burn_in_years=1, horizon 3y, 192 replications, seed 20260924,
deterministic seed derivation, convergence diagnostics passed
100.0% of 2,400 cells (§3.1 line 109); backlog (not discard) carries
unserved demand; FIFO aging in model.py. STATUS: RES.

### H — Grid robustness overstatement
[Editor] SEVERITY: minor → RES. Dense-grid shift (5|10 → 5.25|10) is
already disclosed and used to refuse market claims (§3.8).

### I — Is COR the right outlet?
[Editor] SEVERITY: major externally, RES internally.
The honest answer is the one the package already gives: a decision
model + validated inclusion principle + falsification apparatus, with
explicit comparator experiments — COR's stated bar. Whether an editor
reads "constructive algorithmic complexity" to require a new algorithm
is unresolvable by editing; the manuscript does not fabricate one.
STATUS: ACC (disclosed in cover letter positioning and
reports/FINAL_HANDOFF_COR.md).

### J — Manuscript integrity items
[Editor] SEVERITY: minor → FIX.
- J1: title page promises "An archival DOI will be added before
  submission" — no DOI exists; remove/replace. FIX-4.
- J2: cover letter contains inherited industrial-engineering framing
  ("the same industrial-engineering question"), a broad "What none of
  these does" priority claim, and the self-defeating phrase "not a new
  algorithm". FIX-5: rewrite per Gate 4.6 — concrete contribution
  wording, no invented algorithmic novelty, first person retained.
- J3: manuscript line 11 opens with "industrial-engineering decision"
  framing — acceptable inside the manuscript (it IS an IE decision);
  leave.
- J4: "nested in 11 of 25 pairs" (§3.7) plus Table 6 (10 regimes) —
  both accurate to their source CSVs; no fix.

---

## Gate 1 conclusion

No fatal objection survives. The defensible contribution = endogenous
SKU valuation via household inventory process + globally-evaluated
inclusion rule + demonstrated greedy failure on the realistic feasible
set + falsification apparatus (lemma, matched controls, phase maps).
Proceed to Gate 2 verdict: CONDITIONAL GO already satisfied — no new
analysis needed; Gate 4 implements FIX-2/3/4/5 only.
