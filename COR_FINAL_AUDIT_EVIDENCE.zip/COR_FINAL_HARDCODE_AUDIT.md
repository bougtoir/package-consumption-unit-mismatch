# GATE 2 — Final numeric hardcode & stale-result audit

Date: 2026-10-17. Commit 29e138258. Scope: generating code inspected
directly (not the submission zip alone).

## Files inspected

- analysis/run_analysis.py — primary simulation→output/*.csv pipeline
- analysis/run_revision_analyses.py — regime/phase/grid/greedy analyses
- analysis/build_tables.py — all table_* generators (every table reads
  output/*.csv or tables/*.csv via pd.read_csv; verified line-by-line
  index list)
- analysis/build_figures.py — all figure_* generators (verified:
  every figure's data source is a canonical output/*.csv read at
  build time; literals are styling/annotation only)
- analysis/build_manuscript.py — renders numbers only via
  build_revised_metrics() + f() from loaded CSVs
- analysis/build_submission.py, build_reports.py, prepare_data.py,
  verify_sources.py
- src/pcum/model.py — simulation core (contains no result values)
- config/default.yaml — parameters/seeds only
- manuscript_values.csv — 27 rows

## Checks run

1. Literal scan: rg for every reported result magnitude
   (470.8, 36.7, 290.8, 106.5, 113.4, 393.8, 2.779, 429.1, 287.5,
   294.2, 1641, 180.9, 61.8, 0.3888, 0.4992, 0.112, 0.3296) across
   analysis/ + src/ → **zero hits in generating code** (only matches:
   run_audits.py formatters, report .md files).
2. Pattern scan: override/workaround/patch/hardcod/manual → only
   legitimate `adaptation_probability_override` /
   `adaptation_min_ratio_override` regime-parameter plumbing in
   model.py (regime definitions, not results).
3. Stale-result check: every figure/table generator's read_csv points
   at current output/*.csv (names verified); no generator reads a
   dated/copy CSV or a second copy of results. submission/COR/ artifacts
   regenerated this pass from current builders.
4. Duplication check: result numbers exist in exactly one canonical
   place (output/*.csv); manuscript_values.csv rows cite their
   analysis_source/input_source/code_source per row.
5. Post-change reuse: the only analysis added this cycle
   (run_greedy_vs_global) reads current portfolio_results.csv; all
   regime/candidate/model definitions unchanged since those outputs
   were generated — verified values identical to manuscript (Gate 3
   table in COR_NUMERIC_HARDCODE_AUDIT.md).

## Findings

| file | line | item | class | impact | action |
|---|---|---|---|---|---|
| config/default.yaml | 6 | seed 20260924 | legitimate constant | none | none |
| config/default.yaml | 16-18 | candidate grid, benchmark portfolio, price | legitimate assumption | none | none |
| src/pcum/model.py | 384-385 | 0.75 price floor | legitimate model assumption (config family) | none | none |
| src/pcum/model.py | 147-8, 257-63 | *_override regime parameters | legitimate mechanism | none | none |
| analysis/build_figures.py | various | axis limits, annotation strings, colors | legitimate formatting | none | none |
| — | — | any reported result value in generators | **none found** | — | — |

No illegitimate hardcoded outputs, no stale CSV reuse, no duplicated
divergent result copies, no hidden overrides or fabricated values.
PASS.
