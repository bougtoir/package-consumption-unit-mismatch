# GATE 3 — Text / figure / table consistency (final pass)

Date: 2026-10-17. Commit 29e138258+.

## Regeneration (once)

- build_figures.py → figures/figure_1–9.{png,pdf} regenerated from
  output/*.csv (single run)
- build_tables.py → tables/table_1–15.csv + supplement tables from
  canonical outputs (single run)
- build_manuscript.py → manuscript.docx, manuscript_with_figures.docx,
  supplement.docx, title_page.docx, cover_letter.docx, highlights.txt
- build_submission.py → submission/COR/ + COR_transfer_FINAL_AUDITED.zip

## Rendered-artifact inspection

- Figure 1 (conceptual distinction): opened and visually inspected —
  boxes/arrows/labels correct.
- Figure 4 display (figure_6_sku_break_even.png): opened and inspected —
  three SKU curves cross at the reported thresholds (~470.9 / ~36.8 JPY).
- figure_table_audit + figure_quality_audit suites: PASS (all 9 figures
  ≥1800×1000 px, numbering/citation order consistent).
- docx text extracted and checked: manuscript, supplement, title page,
  cover letter all reflect the same canonical revision — Table 6 =
  greedy, Tables S1–S9 + Figures S1–S4 in supplement, Figure_1–5
  separate files matching display numbering.

## Cross-reference & consistency checks

- Every in-text "Table N" / "Figure N" / "Table SN" / "Figure SN"
  resolves to a produced object (number_objects() enforces
  first-citation ordering; build fails otherwise — it did not).
- Units consistent: JPY/household-year for costs, kg for discard,
  g for residual, percent for phase shares.
- Abstract/contributions/discussion numbers identical to traced values
  (reports/COR_NUMERIC_PROVENANCE.csv).
- Captions match figure contents (break-even = thresholds, phase map =
  SKU-count regions); supplement self-contained.
- Cover letter synchronized: same thresholds, same greedy claim,
  same calibration caveats as manuscript.

## Result

All text, figures, tables, captions and supplement derive from the
same canonical result version. PASS.
