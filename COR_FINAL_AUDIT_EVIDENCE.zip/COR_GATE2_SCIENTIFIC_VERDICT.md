# GATE 2 — COR scientific soundness verdict

Verdict: **PASS to Gate 3.**

The CAIE-era Gate 2 (`GATE2_SCIENTIFIC_VERDICT.md`), hostile review
(`HOSTILE_IJPE_REVIEW.md`), and parameter-evidence audit remain valid;
this gate re-checks the surviving COR contribution against COR's
specific reviewer attacks, reusing only canonical outputs plus the one
new evaluation file `output/greedy_vs_global_portfolio.csv`.

## 1. Does the surviving contribution survive the controls?

| Attack | Evidence | Status |
|---|---|---|
| Discrete consumption quantum may be the whole story | Matched continuous controls: lattice main effect −106.1 to −142.0 JPY/hh-yr (≈0.1% of cost), 0.000 kg discard — discreteness is second-order and the paper says so | Survives; framed as regime characterization |
| Carry-over/no-spoilage boundary | No-spoilage control exactly 0.000 kg under all three usage processes; exit mechanisms are necessary for any discard claim | Survives |
| Candidate-grid dependence | Coarse 9/5|10/5|9|10 vs dense 9/5.25|10/5.25|8|10; multi-SKU identities labeled calibration-dependent | Survives; structural claims only |
| Heterogeneous households | Six scenario classes with explicit weights; called design scenarios, never population segments | Survives with existing labels |
| Uncertain scenario parameters | Parameter-evidence audit labels anchors/assumptions/unidentified; SKU cost reported as break-even threshold, not estimate | Survives |
| Greedy failure is candidate-set luck | Non-nestedness observed across 6 of 10 independent regimes (different hazard/cost/usage-process settings) with consistent 106.5–113.4 JPY magnitude; it is not one lucky cell | Survives |

## 2. Structural vs scenario-dependent

- **Structural (defensible):** the coupled model object; the break-even
  inclusion rule evaluated over global optima; non-nestedness of optimal
  portfolios under household-inventory-derived value functions; the
  falsification design (matched controls + phase map).
- **Scenario-dependent (must stay labeled):** all portfolio identities,
  the 470.9/36.8 JPY thresholds, phase-map shares (38.9/49.9/11.2%),
  benchmark regret 180.0 JPY, safety margin 61.8 g. No market-optimal or
  Japan-optimal claims anywhere.

## 3. Most serious COR reviewer attacks

1. **"No constructive algorithmic complexity."** True — no new
   algorithm exists and none will be claimed. The manuscript must be
   positioned as a modeling + decision-principle paper (COR's
   application stream), with the greedy-vs-global quantification as the
   "comparison to other approaches" evidence. Residual desk-reject risk
   remains and is disclosed in the handoff.
2. **"Tautological threshold."** The inequality itself is trivial; what
   is nontrivial is that it must be applied to *global* optima because
   marginal rules demonstrably fail. Prose must state this precisely —
   the rule plus its demonstrated necessity, not the algebra.
3. **"Model realism / producer costs unobserved."** Break-even framing
   already converts the unobservable into a decision variable boundary;
   complexity cost is never estimated.
4. **"Consumer behavior invented."** Usage processes are scenario
   draws; negative controls and regime sweeps bound sensitivity; no
   behavioral calibration is claimed.

## 4. Fatal problems found

None that a targeted fix cannot resolve. One prose obligation: the
manuscript may currently present the inclusion rule as a headline
analytical result; for COR it must be presented as a decision rule whose
*necessity of global evaluation* is the demonstrated finding.

**PASS.**
