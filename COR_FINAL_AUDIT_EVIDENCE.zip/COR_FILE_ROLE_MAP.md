# COR submission file role map

Target journal: Computers & Operations Research (COR), Elsevier.
Route: subscription (no fee); gold OA APC USD 3,490 not used.
Review: single-anonymized — blinded manuscript without author identifiers;
title page separate.

## Upload files

| File | Role | Source |
|---|---|---|
| manuscript.docx | Blinded main manuscript (no author block) | manuscript/manuscript_blinded_submission.docx |
| manuscript_with_figures.docx | Blinded manuscript with figures/tables inline (review convenience copy) | manuscript/manuscript_blinded_review.docx |
| title_page.docx | Title page (title, author, affiliation, word counts, declarations) | manuscript/title_page.docx |
| cover_letter.docx | Cover letter to COR Editor-in-Chief, first person | manuscript/cover_letter.docx |
| highlights.txt | Highlights (5 items, each ≤85 chars incl. bullet) | manuscript/highlights.txt |
| supplement.docx | Supplementary material (Tables S1–S9, Figures S1–S4) | manuscript/supplement.docx |
| figures/Figure_1…5.{png,pdf} | Individual main-text figure files | see crosswalk below |
| pcum_figures_editable.pptx | Editable figure file (Elsevier editable-graphics option) | submission/pcum_figures_editable.pptx |
| pcum_tables_editable.docx | Editable table file | submission/pcum_tables_editable.docx |

## Figure crosswalk

| Display | Source file stem |
|---|---|
| Figure_1 | figure_1_conceptual_distinction |
| Figure_2 | figure_3_lattice_negative_control |
| Figure_3 | figure_4_consumption_sensitivity |
| Figure_4 | figure_6_sku_break_even |
| Figure_5 | figure_7_sku_phase_map |
| S1–S4 (in supplement.docx) | figure_2, figure_5, figure_8, figure_9 |

## Notes

- Supplement is submitted inside `supplement.docx` only (single file).
- `COR_transfer_FINAL_AUDITED.zip` is the packaged copy of the above for transfer.
- Manuscript table numbering now includes Table 6 (nested greedy vs global
  portfolio selection); supplement tables remain S1–S9.
