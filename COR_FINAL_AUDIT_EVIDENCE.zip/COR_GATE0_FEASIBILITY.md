# GATE 0 — COR transfer feasibility

Verdict: **PASS to Gate 1** (with a scope bar flagged as decisive for Gate 1/2).

Date: 2026-10-17. Branch: `devin/1792275721-pcum-cor-gate`
(off `devin/1792122050-pcum-caie-final`, all post-CAIE work; that branch is
not yet merged into master).

## 1. Project state (recorded, no rebuild)

- Canonical manuscript source: `analysis/build_manuscript.py`
  (`build_revised_sections()` + `<<fig:>>`/`<<tab:>>` tokens; main 5
  figures + 5 tables; supplement Tables S1–S9, Figures S1–S4).
- Frozen science: `manuscript_values.csv` (23 values) — max terminal
  residual 393.8875 g; max cell discard 2.779 kg/hh-yr; portfolios
  9 / 5|10 / 5|9|10 (coarse) and 9 / 5.25|10 / 5.25|8|10 (dense);
  SKU thresholds 470.883 / 36.763 JPY; 1-vs-2 diff 290.883
  (287.554–294.212); minimax 5|10 @429.117; safety margin 61.805 g.
- Formal results: `reports/FORMAL_RESULTS.md` — Lemma 1 (zero-discard
  boundary) and the SKU-inclusion condition c < V_k − V_{k+1}.
- Prior gate trail intact: GATE0–GATE6 for IJPE/CAIE,
  `CLOSEST_PRIOR_STUDIES.csv` (10 works), `CITATION_ECOLOGY.md`,
  `CAIE_SCOPE_FIT_FINAL.md`, `HOSTILE_IJPE_REVIEW.md`.
- CAIE package preserved at `submission/CAIE/` (upload-ready zip,
  FILE_ROLE_MAP, FINAL_SUBMISSION_HANDOFF GO verdict) — untouched.
- No `.venv` on this VM yet (snapshot build incomplete); rebuild only
  if/when Gate 3 needs it.
- Public mirror `bougtoir/package-consumption-unit-mismatch` is live
  (HEAD 3dff877) — COR data/code access requirement already satisfied
  in kind.

## 2. Rejection context

CAIE-D-26-08126 desk-rejected ("does not represent a significant
contribution to the literature of industrial engineering"); IJPE
desk-rejected earlier. Elsevier offered ATS transfer candidates:
Computers & Operations Research, Expert Systems with Applications,
IJPE, Transportation Research Part E. Only COR is evaluated here.
A transfer suggestion is not an endorsement or acceptance signal.

## 3. COR verification (authoritative sources)

Source: ScienceDirect Guide for Authors + open-access options page
(fetched 2026-10-17).

- Scope: seven areas — Transportation; Logistics and Supply Chains;
  Production and Scheduling; Decision-Making under Uncertainty and Data
  Analytics; Optimization—Exact Methods; Optimization—Approximate
  Methods; Machine Learning and Data Science. PCUM's closest homes:
  Logistics/Supply Chains (packaging portfolio) or Decision-Making
  under Uncertainty (stochastic household inventory). Scope per se does
  not exclude the paper.
- **Decisive stated bar:** "All full-length research papers published in
  the journal must demonstrate constructive algorithmic complexity and
  extensive numerical experiments. Numerical illustrations (examples)
  are not sufficient: the numerical experiments must have a scientific
  value of their own, particularly with comparisons to other
  approaches." PCUM's computation is exhaustive enumeration over ≤38
  candidate sizes + Monte Carlo; there is no new algorithm and no
  comparison against alternative methods. Whether the "numerical
  experiments have scientific value of their own" is adjudicated in
  Gate 1/2 — this is the single most likely desk-reject reason at COR.
- Also: "does not endorse papers that present long and unsolvable
  formulations for variants/extensions of existing problems and then
  resort to a well-established approximate method." (PCUM's formulation
  is not long/unsolvable; enumeration is exact, so this clause is less
  threatening but related.)
- Review model: **single anonymized** — reviewers anonymous, author
  identity visible. The CAIE double-anonymized manuscript may be
  submitted non-anonymized; a separate title page is standard.
- References: **Harvard style** (author–year) — the manuscript is
  already APA 7th author–year; only formatting-level differences apply.
- Reproducibility: "authors should grant full access to the data and
  codes underlying their work" — satisfied by the live public mirror.
- Publishing routes: **Subscription = no publication fee** (verified).
  Gold OA optional at USD 3,490 APC. Green self-archiving available
  under embargo. Choice does not affect review.
- Abstract requirement: must concisely describe (1) problem,
  (2) theoretical/methodological contribution, (3) insights.
- Highlights: listed as a guide section (Elsevier-standard 3–5 bullets,
  ≤85 chars); confirm exact wording at Gate 3.
- Warfare-activity papers excluded — irrelevant.

## 4. Transfer mechanics (Elsevier ATS)

- The offer arrives by email / Editorial Manager; the **author must
  initiate** via the offer link or the pending offer in EM. Offers
  expire after ~130 days by default (auto-declined).
- Files transfer without re-upload; review comments transfer only if
  the sending journal configured it (CAIE desk reject → likely no
  reviews attached). Author may revise before finalizing the new
  submission.
- Transfer does **not** waive peer review and is not an acceptance
  signal; COR will make its own editorial decision.
- User-only steps: click the ATS offer / select COR in EM, complete the
  EM questionnaire, finalize submission. Devin prepares the package
  only.

## 5. Gate 0 conclusion

No blocking facts: scope category exists, subscription (no-fee) route
exists, transfer mechanics are real, public code/data availability is
already in place. Proceed to Gate 1 with the "constructive algorithmic
complexity + scientific-value numerical experiments" bar as the
decisive criterion.
