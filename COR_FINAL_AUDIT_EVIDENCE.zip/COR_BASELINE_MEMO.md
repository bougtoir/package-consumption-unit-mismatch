# GATE 0 — Baseline memo (hostile-review round)

Date: 2026-10-17
Commit: a5b70a592 on devin/1792275721-pcum-cor-gate (post-Gate-4 COR package,
PR #702 open, unmerged)

## Current state

- COR transfer package built in previous pass: submission/COR/
  (manuscript.docx, manuscript_with_figures.docx, title_page.docx,
  cover_letter.docx, supplement.docx, highlights.txt,
  figures/Figure_1-5.{png,pdf}, editable pptx/docx, COR_transfer_READY.zip)
- Manuscript main results (all generated from output/*.csv via
  build_manuscript.py metrics, none hand-typed):
  - Global 1/2/3-SKU optima: 9, 5|10, 5|9|10 kg (baseline)
  - Break-even charges: 470.9 / 36.8 JPY/household-year per added SKU
  - Paired 1-vs-2-SKU difference: 290.9 (95% MC 287.6–294.2) JPY
  - Zero discard in full carry-over/no-spoilage (0.000 kg); baseline max
    discard 2.779 kg
  - Greedy vs global: nested greedy misses optimal 2-SKU set in 6/10
    regimes, regret 106.5–113.4 JPY (greedy_regret_at_3 = 0 in all 10 —
    failure is confined to the first inclusion decision)
- Tests: 14/14 pytest pass; ruff clean; all audit suites pass
  (reference, numeric traceability, hardcode, figure/table,
  submission compliance, etc.)
- manuscript_values.csv: 27 rows, all traced to output/*.csv + code paths

## COR requirements (re-verified; Guide for Authors, ScienceDirect)

- Scope: optimization/OR incl. logistics, supply chains, decision under
  uncertainty — PCUM fits as a decision model for SKU portfolio inclusion.
- Editorial bar: "constructive algorithmic complexity and extensive
  numerical experiments... particularly with comparisons to other
  approaches" — the greedy-vs-global comparison now supplies an explicit
  comparator; the model itself is a decision model, not a new algorithm.
- Single-anonymized review: blinded manuscript + separate title page — OK.
- Harvard (author–year) references — OK.
- Subscription route: no mandatory fee; gold APC USD 3,490 unused.
- Data/code availability: public repo required — present; title page
  currently contains an unissued "archival DOI will be added" promise
  (flagged for removal in Gate 4).
- A transfer offer is not an acceptance signal — treated accordingly.

## Decision

Proceed to Gate 1 hostile review on the current COR revision.
