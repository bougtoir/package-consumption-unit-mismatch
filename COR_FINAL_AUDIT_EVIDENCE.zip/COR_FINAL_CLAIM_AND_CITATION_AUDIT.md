# GATE 4 — Claim & citation audit (final pass)

Date: 2026-10-17. Commit 29e138258+.

## Closest-prior-study positioning

- reports/COR_CLOSEST_PRIOR_STUDIES.csv: 11 verified papers.
- Discussion §4.1 makes the specific contrast (endogenous SKU value vs
  exogenous choice/substitution functions in Gaur & Honhon 2006,
  Kök & Fisher 2007, van Ryzin & Mahajan 1999) — no sweeping
  "none of these" language remains in cover letter or manuscript
  (verified by docx text extraction: 'none of these' = absent).
- In-text citations vs reference list: reference_audit suite PASS —
  all entries cited, no orphans, no duplicate DOIs, APA order valid.

## DOI existence (Crossref-verified identifiers)

- Gaur & Honhon 2006: 10.1287/mnsc.1060.0580 — verified.
- Kök & Fisher 2007: 10.1287/opre.1070.0409 — verified.
- All other DOIs unchanged from the previously verified list
  (reference_audit: identifier_well_formed all True).
- New in this cycle: only the two above; both materially support the
  assortment-plus-inventory contrast claim.

## Cover letter corrections applied (this pass)

- "which settles when the common 'remainder equals waste' shortcut is
  valid" → "marks the exact boundary at which the common
  'remainder equals waste' shortcut starts to fail" (precise boundary
  formulation).
- unqualified "the discrete lattice adds no discard" → "under full
  carry-over the discrete lattice contributes zero discard and is
  second-order in generalized cost" (calibration-scoped).
- Previously applied and re-verified: first-person singular throughout;
  no "industrial-engineering" boilerplate; no "What none of these
  does" priority claim; no "not a new algorithm" disclaimer; no
  invented archival DOI; journal name COR; declarations accurate;
  data/code availability describes the public repository and the
  restricted-snapshot exclusion truthfully.

## Proportionality check

Abstract/contributions/discussion/cover letter all use
calibration-dependent, scenario, and negative-result language;
no universal-optimum or market-recommendation claim; no invented
algorithm. PASS.
