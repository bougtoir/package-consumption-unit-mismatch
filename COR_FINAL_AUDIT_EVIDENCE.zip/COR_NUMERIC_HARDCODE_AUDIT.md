# GATE 3 — Numeric hardcode & provenance audit (COR revision)

Date: 2026-10-17. Baseline: reports/COR_BASELINE_MEMO.md (commit a5b70a592).

## Method

Traced each key quantitative claim: output/*.csv (canonical results) →
manuscript_values.csv → build_manuscript.py metrics/formatters →
manuscript_source.md. Grepped all result-generating and manuscript-build
scripts for suspicious result-value literals; inspected each hit's role.
Verified headline claims directly against canonical CSVs (spot
re-computation, not rebuild).

## Verdict

No prohibited hardcoding found. All manuscript result numbers render via
`build_revised_metrics()` + `f()` formatters from canonical CSVs; the
only literals in builders are formatting (digits), seeds, unit labels,
and structural constants (see CSV detail). manuscript_values.csv covers
all 27 key values including the 3 new greedy rows added in the COR pass.

## Key claims traced (claim → canonical source → status)

| Claim in COR manuscript | Canonical source | Verified |
|---|---|---|
| zero discard, full carry-over/no-spoilage | output/size_household_metrics.csv (max 0.000) + Lemma 1 | OK |
| baseline max discard 2.779 kg | output/size_household_metrics.csv | OK (2.7793588643) |
| max terminal residual 393.9 g | output/terminal_residual.csv | OK (393.8875) |
| best 1/2/3-SKU portfolios 9, 5|10, 5|9|10 | output/portfolio_results.csv | OK |
| thresholds 470.9 / 36.8 JPY | output/sku_inclusion_thresholds.csv | OK (470.8827 / 36.7627) |
| paired 1-vs-2 diff 290.9 (287.6–294.2) | output/portfolio_contrasts.csv | OK (290.8827, CI 287.554/294.212) |
| benchmark regret 114.2–180.0 | output/consumption_transition_thresholds.csv-derived text | OK |
| minimax 5|10, max regret 429.1 | output/robust_portfolios.csv | OK (429.1173) |
| phase shares 38.9/49.9/11.2 %; modal 10 kg 33.0 % | output/sku_phase_map.csv | OK (0.3888/0.4992/0.1120; 0.3296) |
| thresholds 0.0–1,641.9 / 0.0–180.9; nested 11/25 | output/sku_phase_threshold_curves.csv | OK (max 1641.946 / 180.943; 11/25) |
| dense-grid optima 9, 5.25|10, 5.25|8|10 | output/candidate_grid_robustness.csv | OK |
| greedy 6/10 regimes, 106.5–113.4 JPY | output/greedy_vs_global_portfolio.csv | OK (6 rows >0; 106.5046–113.4468) |
| safety margin 61.8 g | output/manufacturing_precision.csv | OK (61.8046) |
| 100.0% of 2,400 MC diagnostics | output/convergence_diagnostics.csv | OK (existing audit) |
| 8 unidentified / 6 scenario inputs | Table 2 generator | OK (counted in table build) |
| lattice/spoilage/interaction -112.9/622.3/3.8 | output/lattice_factorial_decomposition.csv | OK (existing audit) |

## Suspicious-literal scan

`rg` over analysis/build_manuscript.py, build_tables.py, build_figures.py,
build_submission.py, run_revision_analyses.py, run_analysis.py for the
result magnitudes above: **zero hits** — no result value is typed into a
builder. Legitimate literals inspected and cleared: seeds (20260924),
candidate size grid [1.8…10], benchmark portfolio [2,5,10], rounding
digits, currency strings, and the 0.75 price floor inside
`effective_price` (a documented config assumption, not a result).

## Stale-version check

submission/COR/ files were regenerated this pass from current builders;
the zip was rebuilt and integrity-checked by build_submission.py.
CAIE/IJPE directories were restored to HEAD (preserved history, not
regenerated — deliberate).

## Defects found

None blocking. One documentation item carried to Gate 4: title page
contained an unissued "archival DOI will be added" promise (removed).
