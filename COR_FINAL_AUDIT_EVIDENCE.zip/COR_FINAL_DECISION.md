# GATE 6 — COR final decision

Date: 2026-10-17. Branch: devin/1792275721-pcum-cor-gate (PR #702).
Decision: **GO** (transfer-ready package produced; no external
submission initiated — that requires explicit user approval).

## Strongest defensible contribution

A coupled decision model that prices each candidate consumer SKU inside
a stochastic household carry-over inventory process (endogenous SKU
value — not an exogenous choice/substitution function as in Gaur &
Honhon 2006, Kök & Fisher 2007, van Ryzin & Mahajan 1999) and evaluates
the SKU-inclusion decision by exact enumeration under an explicit
complexity charge. The demonstrated consequence: nested greedy fails on
the realistic feasible set (6/10 regimes, 106.5–113.4 JPY, confined to
the first inclusion step). Nearest prior work optimizes producer-side
package sets under deterministic/aggregate demand or fixes the retail
offering when simulating households.

## Hostile objections resolved vs remaining

Resolved/answered (reports/COR_HOSTILE_REVIEW.md):
A1 novelty-as-identity (RES — contribution stated as integrative),
A2 non-submodularity known (RES — claim is computational, bounded),
B prior studies (RES — 11 verified papers, explicit contrast),
C greedy verification (RES + FIX — k=3 confinement now stated),
D controls (RES — honest second-order finding),
E transfer mixing (FIX — clarifying sentence added §2.3),
F identification (RES), G validity (RES), H grid (RES),
J integrity (FIX — DOI promise removed; cover letter de-boilerplated).
Remaining: I — COR's "constructive algorithmic complexity" bar may still
be read as requiring a new algorithm; disclosed honestly, not masked.

## Numeric claims traced / hardcoding

All key claims traced to canonical output/*.csv → manuscript_values.csv
→ rendered text; zero result literals in builders
(reports/COR_NUMERIC_HARDCODE_AUDIT.md + COR_NUMERIC_CLAIMS_TRACE.csv).
No prohibited hardcoding; defects found: none computational.
(One audit check updated to assert the now-removed DOI promise.)

## Analyses rerun

None — Gate 3 verified all values against existing canonical outputs;
no model change, so no simulation rerun. Manuscript/docx/zip rebuilt once.

## Scientific values changed

None (old → new identical). Text-only revisions:
- §2.3: purchase-outlay/transfer clarification sentence
- §3.6: greedy failure confined to first inclusion (k=3 regret = 0)
- title page: unissued archival-DOI promise removed
- cover letter: rewritten — concrete COR contribution wording, no
  "industrial-engineering" boilerplate, no "none of these" priority
  claim, no "not a new algorithm" disclaimer, first-person retained

## Final files & tests

- submission/COR/COR_transfer_REVISED_READY.zip (18 files, integrity
  checked, no zero-byte, no nested archive) + FILE_ROLE_MAP.md
- manuscript.docx / manuscript_with_figures.docx / title_page.docx /
  cover_letter.docx / supplement.docx / highlights.txt / Figure_1–5
- manuscript_values.csv (27 rows) unchanged in content
- run_audits.py: all suites pass; pytest 14/14; ruff clean

## Stop

One targeted pass complete. Preserved all prior outputs and CAIE/IJPE
history. No Editorial Manager action taken.
