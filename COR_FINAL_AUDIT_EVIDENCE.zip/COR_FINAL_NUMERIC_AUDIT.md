# GATE 3 — Final numeric audit

Date: 2026-10-17. Commit 29e138258+. Companion file:
reports/COR_NUMERIC_PROVENANCE.csv (all claims, sources, status).

## Required values — all verified against canonical outputs

| value | reported | canonical | denominator/scope | status |
|---|---|---|---|---|
| zero discard | 0.000 kg/hh-yr | size_household_metrics max=0.0 | full carry-over + no spoilage regime | OK |
| residual | 393.9 g | terminal_residual max mean 393.8875 | max mean one-package terminal residual | OK |
| discard | 2.779 kg | size_household_metrics 2.7793589 | max cell, baseline with spoilage | OK |
| threshold 1→2 | 470.9 JPY | sku_inclusion_thresholds 470.8827 | baseline regime, per added SKU | OK |
| threshold 2→3 | 36.8 JPY | sku_inclusion_thresholds 36.7627 | baseline regime, per added SKU | OK |
| paired diff | 290.9 (287.6–294.2) | portfolio_contrasts 290.8827 CI 287.554–294.212 | baseline; 95% MC interval = simulation error only | OK |
| greedy fail | 6/10; 106.5–113.4 | greedy_vs_global 6 rows; 106.5046–113.4468 | 10 prespecified regimes, at k=2 | OK |
| greedy k=3 | 0 (all regimes) | greedy_regret_at_3=0 | same | OK |
| phase shares | 38.9/49.9/11.2 % | sku_phase_map 0.3888/0.4992/0.1120 | share of 25×? phase cells (625-cell map) | OK |
| modal | 10 kg = 33.0 % | sku_phase_map 0.3296 | cell share | OK |
| coarse/dense optima | 9 / 5.25|10 / 5.25|8|10 vs 9 / 5|10 / 5|9|10 | candidate_grid_robustness vs portfolio_results | coarse 10-size vs dense 38-size | OK |
| minimax | 5|10; 429.1 JPY | robust_portfolios 429.1173 | max within-regime regret, declared regimes | OK |
| threshold ranges | 0.0–1641.9 / 0.0–180.9 | phase_threshold_curves | 25 spoilage×purchase pairs | OK |
| nested | 11/25 pairs | phase_threshold_curves | from=1→2 nested flag | OK |
| safety margin | 61.8 g | manufacturing_precision 61.8046 | σ=20 g, α=0.001 | OK |
| MC diagnostics | 100.0% of 2400 | convergence_diagnostics | 4 metrics × regime-scenario-size cells | OK |
| input labels | 8 unidentified / 6 scenario | Table 2 build | parameter_evidence table | OK |

## Rounding/units/scope notes

- All manuscript numbers render via f() at 1 decimal (or stated %);
  no value contradicts its canonical precision after rounding.
- MC intervals are labeled "95% Monte Carlo interval" = simulation
  error conditional on parameters; parameter uncertainty is
  explicitly NOT quantified (§3.1, §4.3) — verified in text.
- Denominators (per household-year, per added SKU, per phase cell)
  verified in text and captions.

PASS — no discrepancy required an analysis rerun.
