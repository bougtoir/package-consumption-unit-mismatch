# GATE 1 — COR novelty verdict

Verdict: **CONDITIONAL PASS → satisfied → PASS to Gate 2**
(one bounded analysis run once; falsifiable criterion met).

Date: 2026-10-17. Base for comparison: `reports/COR_CLOSEST_PRIOR_STUDIES.csv`
(11 closest works, all DOI-verified; the CAIE-era list plus Gaur & Honhon
2006, the canonical assortment-plus-inventory model).

## What was tested (mandatory checks)

1. **Lemma 1 (zero-discard boundary)** — the proof is a bookkeeping
   identity: E_t = 0 by assumption ⇒ ΣE_t = 0. It is conservation of
   mass. It stays in the manuscript as a *boundary lemma* that redirects
   modeling effort toward exit mechanisms; it cannot carry an OR
   contribution claim.
2. **SKU-inclusion condition c < V_k − V_{k+1}** — immediate algebra of
   the stated objective J_k = V_k + (k−1)c. Not a theorem. Its value is
   as a *decision rule* evaluated over globally optimized (non-nested)
   portfolios — see below.
3. **Enumeration + Monte Carlo** — enumeration over ≤38 candidate sizes
   and household simulation are standard computation. No new algorithm
   is claimed anywhere.

## The one bounded analysis (CONDITIONAL criterion)

*Question:* does the claimed "non-nested optima ⇒ marginal assortment
rules mislead" actually bite, or is it decorative?

*Method:* greedy nested SKU construction (pick argmin single size; keep
it and pick the argmin pair containing it; keep and extend to triple)
versus the globally optimal k-SKU portfolio, on the already-frozen
`output/portfolio_results.csv` (all 175 k≤3 subsets of the 10-size
coarse grid × 10 regimes). No new simulation; pure evaluation of
existing canonical outputs → `output/greedy_vs_global_portfolio.csv`.

*Pre-registered falsifiable criterion:* if greedy achieves the global
optimum at every cardinality in (nearly) all regimes, the non-nestedness
framing collapses and Gate 1 issues NO-GO.

*Result:* greedy fails at k=2 in **6 of 10 regimes** (baseline,
zero/high SKU complexity, no-discrete-quantum, randomized usage,
final-batch adaptation), locking in single-size winner 9 kg and missing
optimal pair 5|10 by **106.5–113.4 JPY/household-year**; the optimal
pair provably excludes the best single (nested_at_2 = False). At k=3
greedy recovers (0 regret). The non-nestedness is real, quantified, and
material at the decision point that matters (the one-to-two inclusion
threshold of 470.9 JPY).

## What survives as the OR contribution

1. **New decision object:** a coupled model in which a stochastic
   household carry-over inventory (aging, spoilage exit, backlog,
   end-of-horizon adaptation) generates the consumer-cost input to a
   producer package-SKU portfolio problem. None of the 11 closest works
   couples consumption-side inventory dynamics to the offered-size-set
   decision (Koenigsberg 2010 prices one size; van Rooijen 2024 plans
   deterministic household meals; HHSM 2020 simulates fixed
   interventions; Gámez Albán 2015, Brinker & Gündüz 2016, Wensing 2018
   optimize deterministic size sets; Gaur & Honhon 2006 and
   van Ryzin & Mahajan 1999 assume exogenous choice/substitution
   value functions).
2. **Validated decision principle:** the marginal SKU-inclusion
   break-even must be evaluated over *global* optima because the
   portfolio value function is non-nested; nested greedy selection — the
   natural practitioner rule — is demonstrably wrong by ~107–113 JPY in
   the majority of regimes. This is a computed, falsifiable property,
   not a restatement.
3. **Falsification apparatus:** matched discrete-vs-continuous, lattice
   vs randomized usage, and spoilage-exit negative controls bound *when*
   consumption granularity matters (discreteness is second-order:
   −106 to −142 JPY, 0.000 kg discard) — a design absent from all
   closest works.

## Honest residual risk

COR's stated bar ("constructive algorithmic complexity and extensive
numerical experiments … comparisons to other approaches") is not fully
met: there is no new algorithm, and the comparisons are greedy-vs-global
and regime-vs-regime, not competing methods. The surviving contribution
is a *modeling + decision-principle* contribution, typical of COR's
application side but thin against the strictest reading of the bar.
This risk is carried into the cover letter and positioning rather than
papered over: the manuscript must sell the coupled model and the
validated inclusion principle without claiming algorithmic novelty.

## Decision

PASS — proceed to Gate 2. If Gate 2 finds the contribution fails under
the soundness attacks (tautology, candidate-set dependence, unobserved
producer costs), issue NO-GO there.
