# SMPT Gate 1 — Final hostile review (6 personas)

Date: 2026-10-21. Manuscript: submission/SMPT/manuscript_blinded_FINAL.docx (~4,648 words + supplement).

## Persona A — SMPT editor (scope fit)
Verdict: MINOREDIT-LEANING-ACCEPT. "Simulation fidelity vs decision fidelity" framing is squarely a simulation-methodology contribution; deterministic-counterpart ablation is a defensible simulation-design analysis. Risk: application (household rice) is narrow; mitigated by mechanism-transferability discussion and explicit ablation design in §2.6.

## Persona B — OR reviewer
- "Det = stoch argmin (regret 0.0) → why simulate?" → Addressed: ablation is reported as the negative result it is; claim calibrated to canonical candidate set; dense-grid disagreement (1/3 identity matches, adjacent-size swaps, regret ≤4.1 JPY < MCSE) disclosed, not hidden. CRITICAL → resolved as MAJOR-with-disclosure.
- "0.0 regret is circular (regret vs stoch optimum)" → true by construction when identities match; manuscript states the check is about whether stochastic evaluation CHANGES the choice, and §3.11 now reports where it does not match. Resolved.
- Greedy-failure regimes (6/10) and minimax alternative presented; not overstated.

## Persona C — Statistics/Monte-Carlo reviewer
- MCSE pass (mean per-cell ~132 JPY); dense-grid regret (4.1 JPY) is below MC resolution — this is stated, so the honest conclusion is "within noise," not "degraded". Compliant.
- Seeds/timezone fixed; uncertainty reported where used.

## Persona D — Domain (food waste / packaging) reviewer
- Calibration from household rice data; break-even 470.9/36.8 JPY, discard bounds 0.000–2.779 kg, residual 393.9 g — all traceable to outputs. No overstated waste-reduction claims; manuscript explicitly says mismatch alone cannot create discard without an inventory-exit mechanism.

## Persona E — Reproducibility reviewer
- Regenerated end-to-end this audit: figures, tables, all docx, audits 35/35 traceable + 35/35 hardcode-free, pytest 14/14, ruff clean. Reproduce-only public mirror exists (no journal name). Resolved.

## Persona F — Skeptical methodology reviewer
- Deterministic design is fairly matched on demand MEANS (interval=mean_interval, base_planned=mean_usage, adapted=False) but not on trajectory shape; storage/age ≤14% and det−stoch +150.3 JPY mean cost deviation quantified, so the fidelity gap is reported, not hidden. Remaining honest limitation: deterministic variant is one specific choice (mean-trajectory), and dense-grid swaps show det and stoch can pick different (adjacent) sizes — now in §3.11. MAJOR → addressed by disclosure.

## Editorial verdict
No CRITICAL issues remain open. Two MAJOR items were converted to disclosed limitations rather than buried. Recommend: ACCEPTABLE FOR SUBMISSION (conditional on the journal-fit CONDITIONAL flag, i.e., Q1 status unverified at primary source — not a manuscript defect).
