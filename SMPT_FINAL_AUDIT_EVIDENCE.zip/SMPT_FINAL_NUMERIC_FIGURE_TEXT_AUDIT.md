# SMPT Gate 3 — Final numeric / figure / text cross-audit

Date: 2026-10-21. All figures/tables/docx regenerated ONCE this audit (no partial regeneration), then compared.

## Cross-surface consistency
- Text vs tables vs supplement vs highlights vs cover letter: all numbers sourced from manuscript_values.csv / output CSVs; traceability audit 35/35 PASS found_in_manuscript=True.
- Key frozen values consistent everywhere: break-even 470.9 / 36.8 JPY; optimal 9 | 5|10 | 5|9|10 kg; greedy fails 6/10 regimes (106.5–113.4 JPY); discard 0.000–2.779 kg; residual 393.9 g; minimax 5|10 @ 429.1 JPY; phase shares 38.9/49.9/11.2%.
- Ablation: 0.0 JPY regret (coarse), +4.086 JPY max regret / 1-of-3 identity matches (dense), +150.3 JPY mean det−stoch deviation, ≤14% storage/age — same values in §3.11 text, Table 7, supplement.
- Abstract: 238 words (≤250); claim scoped "on the canonical candidate set".
- Table numbering enforced by citation order via `number_objects()` (det table = table_16.csv rendered "Table 7"); supplement S1–S9 tables, S1–S4 figures.

## Visual inspection
- figure_1 (conceptual) and figure_7 (phase map) inspected on-screen: render correctly, labels legible.
- figures/ dir contains exactly the 5 main PNGs; supplement figs embedded only in supplement_FINAL.docx.
- DOCX open correctly (title page, cover letter, supplement verified this audit).

## Gate 3 verdict: PASS.
