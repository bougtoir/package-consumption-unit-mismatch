# SMPT Gate 2 — Final reproducibility audit

Date: 2026-10-21. Environment: repo .venv, PYTHONPATH=src.

## Executed (not assumed)
- `make` targets run in order: build_figures → build_tables → run_deterministic_counterpart (coarse + dense grid) → run_audits → build_manuscript_smpt. All completed, exit 0.
- Ablation re-executed this audit, not inherited: deterministic metrics recomputed from `output/deterministic_*` CSVs; dense-grid extension added to `run_deterministic_counterpart.py` and its outputs verified:
  - Coarse canonical grid: det = stoch argmin for all portfolios and best single sizes; decision regret 0.0 JPY (exact, by identity match).
  - Dense 39-size grid: identities match 1 of 3 SKU counts; det picks 9.25 / 5.25|10 / 5.25|8.25|10 vs stoch 9 / 5.25|10 / 5.25|8|10 (adjacent-size swaps); max decision regret +4.086 JPY < mean per-cell MCSE ~132 JPY.
  - det − stoch cost deviation: mean +150.3 JPY (OVERSTATES), max relative 0.34%; storage ≤13.7%, age ≤13.9%.
- pytest: 14/14 pass. ruff: clean.
- Bit-identical rerun of the ablation confirmed earlier in this audit (same seed/timezone); regenerated figure PNG copied byte-for-byte (MD5 match checked).

## Traceability
- `reports/numeric_traceability_audit.csv`: 35/35 value_ids PASS, all rendered values found in the SMPT manuscript source.
- Gate 2 verdict: PASS.
