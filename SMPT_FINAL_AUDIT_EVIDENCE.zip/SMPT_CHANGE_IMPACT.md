# SMPT Gate 0 — Canonical artifacts and change impact vs COR version

Date: 2026-10-21. Branch: `devin/1792487904-pcum-smpt`. One VM, one working tree.

## Canonical artifacts (SMPT)
- Builder: `analysis/build_manuscript_smpt.py` → `submission/SMPT/` (manuscript_blinded_FINAL.docx, title_page_FINAL.docx, cover_letter_FINAL.docx, supplement_FINAL.docx, highlights_FINAL.txt, figures/ = 5 main PNGs, SMPT_submission_READY.zip)
- Number source: `manuscript_values.csv` + `analysis/build_manuscript_smpt.py` metric functions (no prose literals for generated quantities).
- Analyses feeding SMPT-only content: `analysis/run_deterministic_counterpart.py` (coarse + dense 39-size grids), `analysis/build_tables.py` (`deterministic_counterpart_table` → `tables/table_16.csv`, rendered as "Table 7").

## Diff vs COR version (submission/COR/, builder build_manuscript_cor.py)
- Shared core: model, scenarios, portfolio/simulation outputs, negative controls, audit scripts — unchanged by retarget.
- SMPT-only changes (this session):
  1. New ablation analysis: deterministic counterpart (`src/pcum/model.py` `deterministic` flag, `simulate_package_deterministic`; `run_deterministic_counterpart.py` coarse grid + NEW dense-grid extension added during this audit).
  2. Manuscript reframed for SMPT (simulation methodology framing, single-anonymized format, highlights file, ~250-word abstract = 238 words).
  3. New SMPT-niche references: Onggo 2019 SMPT, Moubed 2021 SMPT (framework transfer in simulation methodology); supporting refs Boz 2026 Sustainability, Zhang & Qi 2020 AAEA.
  4. Bug fixes made during this final audit:
     - `_det_metrics` regime-join bug: deterministic baseline was compared against ALL 11 stochastic regimes (mean −914 JPY, >130% deviation) → filtered to baseline (60 cells): +150.3 JPY mean deviation, ≤14%.
     - Sign fix: det − stoch = +150.3 JPY → deterministic OVERSTATES expected cost (earlier draft said "understates").
     - Honest dense-grid disclosure: on the 39-size grid det/stoch identities match in only 1 of 3 SKU counts (adjacent-size swaps, max regret +4.086 JPY < 132.0 JPY mean per-cell MCSE). Now reported in §3.11.
     - Abstract claim tightened: "recovers every optimal portfolio" → "on the canonical candidate set it recovers…" after dense-grid finding.
- COR audits reused only where files unchanged (numeric traceability and hardcode audits re-run fresh against the SMPT manuscript source anyway — see FINAL_REPRO/FINAL_HARDCODE reports).

## Current official SMPT scope/instructions (verified 2026-10-19 session, re-checked)
- Elsevier, ISSN 1569-190X, Simulation Modelling Practice and Theory; single-anonymized peer review → blinded manuscript carries no author info; author info lives only in title_page_FINAL.docx.
- Hybrid: no mandatory APC (optional OA USD 2,970). JCR Q1 (IF 4.6) via secondary aggregators only → flagged CONDITIONAL, not asserted in the manuscript.
- Abstract limit ~250 words → 238. Highlights: 5 bullets, each ≤85 chars.
- Gate 0 verdict: PASS.
