# SMPT Gate 4 — Final reference & novelty audit

Date: 2026-10-21.

## DOI verification (executed, not assumed)
All 28 DOIs in the SMPT bibliography verified:
- 26/28 resolve via Crossref API with matching journal + year metadata (Management Science ×6, OR ×1, SMPT ×2 [Onggo 2019, Moubed 2021], EJOR, OR Spectrum, J. Simulation, Int. J. Adv. Manuf., CIE, IJPE ×3, J. Cleaner Prod., Resour. Conserv. Recycl., Sci. Total Environ., Sustainability ×2, Food Qual. Pref., J. Food Process Eng., J. Bus. Logist., Packag. Technol. Sci.).
- `10.1016/S0260-8774(00)00068-6` — Crossref API path encoding quirk; resolves 200 at doi.org → Elsevier linkinghub.
- `10.22004/ag.econ.304631` — not registered with Crossref (AgEcon Search RA); resolves 202 at doi.org → ageconsearch.umn.edu record exists.
- Verdict: no fabricated or unverified references. Zero DOI failures.

## Citation entailment
Spot-checks: each SMPT-niche citation used for what the source actually supports (Onggo/Moubed cited as simulation-methodology framework transfer in SMPT, not as household-food results). No citation used to support a claim it does not entail.

## Closest-literature / novelty
Closest prior work remains simulation-framework-transfer papers (Onggo, Moubed) and OR package/portion-sizing literature; none performs a decision-fidelity vs simulation-fidelity ablation of stochastic demand channels on a package portfolio choice. Novelty statement in intro/discussion is scoped to that comparison — defensible, not overclaimed.

## Gate 4 verdict: PASS.
