# SMPT Gate 2 — Final hardcode audit

Date: 2026-10-21. Scope: SMPT manuscript builder prose + tables + figures vs generated outputs.

## Result
- `reports/hard_code_audit.csv`: 35/35 value_ids PASS — every generated number in the manuscript resolves to `manuscript_values.csv` or an output CSV; zero literal numeric claims in prose.
- Fixed during this audit (was literal, now generated):
  - `f(0.0,1)` literal → metric `det_decision_regret_max`.
  - "53.4 kg" / "0.25 kg increments" prose literals → generated from calibration.csv / config.
  - Dense-grid portfolio strings → `det_dense_pick` / `det_dense_stoch` dicts from `deterministic_dense_comparison.csv` (no embedded strings).
- `manuscript_values.csv` updated by `run_deterministic_counterpart.py` with 8 det_* rows incl. det_dense_max_regret_jpy, det_dense_identity_match_count.
- Gate 2 (hardcode component) verdict: PASS.
